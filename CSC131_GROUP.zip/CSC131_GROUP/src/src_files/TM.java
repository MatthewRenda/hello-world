package src_files;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TM {

    public static void main(String[] args) {
        TMModel tm = new TMModel();
        String description = null;
        String data = null;
        String size = null;
        String cmd= null;
        cmd = args[0];
        if (args.length > 1)
            data = args[1];

        if (args.length > 2)
            description = args[2];
        if (args.length > 3) {
            size = args[3];

        }
        switch (cmd) {
            case "startTask":
                tm.startTask(data);
                break;
            case "deleteTask":
                tm.deleteTask (data);
                break;
            case "stopTask":
                tm.stopTask(data);
                break;
            case "taskElapsedTime":
                tm.taskElapsedTime(data);
                break;
            case "taskSize":
                tm.taskSize(data);
                break;
            case "taskDescription" :
                tm.taskDescription(data);
                break;
            case "minTimeForSize":
                System.out.println(tm.minTimeForSize(data));
                break;
            case "maxTimeForSize":
                System.out.println(tm.maxTimeForSize(data));
                break;
            case "aveTimeForSize":
                System.out.println(tm.avgTimeForSize(data));
                break;
            case "taskNamesForSize":
                System.out.println(tm.taskNamesForSize(data));
                break;
            case "sizeTask":
                tm.sizeTask(data, description);
                break;
            case "renameTask":
                tm.renameTask(data,description );
                break;
            case "describeTask":
                tm.describeTask(data, description);
                break;

            case "taskNames":
                System.out.println(tm.taskNames());
                break;
            case "taskSizes" :
                System.out.println(tm.taskSizes());
                break;
            default:
                tm.elapsedTimeForAllTasks();

        }

    }

}